import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;




public class Main {

	 public static void main (String[] args) throws TransformerConfigurationException, IOException, ParserConfigurationException {
		//MainPage container = new MainPage();
		  
		Server newServer = new Server();
		newServer.run();
		 //System.out.println(Integer.parseInt(" "));
		 
		  
	 }
}