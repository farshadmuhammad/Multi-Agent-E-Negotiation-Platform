import java.io.IOException;
import java.net.UnknownHostException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;


public class Main {

	 public static void main (String[] args) throws UnknownHostException, IOException, TransformerConfigurationException, ParserConfigurationException{
		//MainPage container = new MainPage();
		  
		MainPage container = new MainPage();
		 //System.out.println(Integer.parseInt(" "));
		 
		  
	 }
}
